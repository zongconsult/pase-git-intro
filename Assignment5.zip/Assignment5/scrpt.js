var PostID = document.getElementById("itemSelected").innerHTML;
function selectItem() {
  console.log(PostID);
}

function addSelected() {
  var newLi = document.createElement("li");
  newLi.appendChild(document.createTextNode(PostID));
  document.getElementById("userSelected").appendChild(newLi);
}
