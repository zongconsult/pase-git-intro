countries = ["Ghana", "Nigeria", "Togo"]
