var input = prompt("What do you want to do ?");
let items = ["Fish"];

while (input != 'quit') {
  if (input == "list") {
    console.log(items);
  } else if (input == "new" || input == "add") {
    input = prompt("Enter a new item");
    items.push(input);
    console.log(items);
  }
  input = prompt("what you wanna do ?");
}
console.log("You quit the app");
