let userAge = 55;
const PERMIT_AGE = 55;
if (userAge <= 25) {
    console.log('you are too young to play this game')
}
else if(userAge > PERMIT_AGE){
    console.log('come back top enjoy this game')
}
else {
   console.log('Welcome to this nice game') 
}