for (let count = 0; count < 80; count++){
    if(count%2 ==0){
    console.log('count:' + count)
}
}
