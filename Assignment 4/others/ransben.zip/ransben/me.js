var input = prompt("What do you want to do ?")//We take input from a user
let shopping_items = ['Fish','Monkor','Shito','Sabolai','S3b3'] //we have a pre defined list of shopping items

while(input != 'quit' ){
  //whiles the input is not quit then the following ocde should run;because quit end the game
  if(input == 'list'){//is input == list, if so console.log(shopping items)
    console.log(shopping_items)
  }else if (input == 'new' || input=='add'){//else if the user enters add or new 
    input = prompt("Enter your new item");//change the prompt to Enter a new shopping item
    shopping_items.push(input);//then we add the new item to the list with the help of the push method
    console.log(shopping_items)//then we show the items to see if it has been added
  }
  input=prompt("What do you want to do ?") //then we take input again to see if the user wants to quit or not.
}
console.log('You quit the app!')//when the user quits we display this message.

