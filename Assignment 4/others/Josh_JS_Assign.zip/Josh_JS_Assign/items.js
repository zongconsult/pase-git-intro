var name;
let firstName = prompt("What is your firstname?", "Enter your name here...")
    if (firstName == null || firstName == ""){
        name = "User cancelled the prompt.";
    } else{
        name = "Welcome " + firstName + "! Enjoy shopping with us.";
    }
console.log(name);
let stock = ["Orange","Apple","Banana","Kiwi","Mango"];
 var stockInventory = "Here are our items in stock: " + stock
console.log(stockInventory);

let altItems = prompt("Do you wish to specify your own items?", "yes / no")
console.log(altItems)


if (altItems = "Yes" || "yes" || "YES"){
    let stockInput = prompt("Enter items"); 
    stock.push(stockInput);
    console.log(stock);
 } else if (altItems = "No" || "no" || "NO"){
     console.log("Thank you.");
 }

 
