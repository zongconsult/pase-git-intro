alert("Welcome to GTL PaSE Shop")

var userName = prompt("Please, what is your First Name?")

console.log("Welcome " + userName)

alert("Click Ok to View our products")

var shop_items = ["Laptop", "Charger", "Pen Drive", "Hard Disk", "PowerBank"]

console.log("We sell: " + shop_items)

var shop_cart = []

let userItem = prompt("Select items you want to buy")

shop_cart.push(userItem)

let userItem2 = prompt("Enter next item")

shop_cart.push(userItem2)


let userItem3 = prompt("Enter next item")

shop_cart.push(userItem3)

console.log("Shopping Cart: " + shop_cart)


alert("You have selected " + shop_cart)

alert("Thank You! Click ok to quit")

stop();

alert("Done")