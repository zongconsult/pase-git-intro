let start = prompt(
	"Hi, welcome to PaSE Shop. To proceed press 'y' or press any key to exit"
);

let shoppingList = ["Bread", "Coke", "Sugar", "Milk", "Milo"];
let userCart = [];

function itemExist(item) {
	if (shoppingList.includes(item)) {
		return true;
	}
	return false;
}

function addToCart() {
	let s = prompt("Select an item from the list. -> " + shoppingList);

	if (itemExist(s)) {
		userCart.push(s);
	}
	return false;
}

if (start == "y" || "Y") {
	addToCart();
	while (true) {
		if (confirm("Continue shopping?")) {
			addToCart();
		} else {
			break;
		}
	}
	alert("Here is your checkout list: " + userCart);
} else {
	alert("Thanks for passing by");
}
