var list = ['mango', 'range rover', 'vans'];
var userItem;

while (input !== 'c') {
  var input = prompt(
    'welcome to my shopping list: \n' +
      'press a to view list \n' +
      'press b to add to list \n' +
      'press c to quit'
  );

  if (input === 'a') {
    console.log(list);
  } else if (input === 'b') {
    input = prompt('add the item');
    userItem = input;
    list.push(userItem);
    console.log(list);
  } else {
    window.close;
  }
}
