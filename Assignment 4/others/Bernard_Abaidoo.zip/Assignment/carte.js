let myCarte = ["orange", "kiwi", "mango", "guava"];
let endPurchase = false;



while (endPurchase == false) {
    let optionInput = prompt("What do you want to do ");
    if (optionInput == "new") {
        let addNew = prompt("Enter item to add to carte ");
        myCarte.push(addNew);
    }else if (optionInput == "list" ) {
        console.log(myCarte);
    }else if (optionInput == "end"){
        endPurchase = true
    }
}